/*********************************************************************************************************//**
 * @file    IAP_HID/IAP_HID_III/Src_AP/ap_handler.c
 * @version $Rev:: 3206         $
 * @date    $Date:: 2025-03-19 #$
 * @brief   This file contains AP handler.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"
#include "ht32_board_config.h"

#include "ap_handler.h"
#include "ap_config.h"
#include "ap_crc16.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_HID IAP HID
  * @{
  */

/** @addtogroup IAP_HID_III IAP HID III (with Encrypt and Command Key)
  * @{
  */

/** @addtogroup IAP_HID_III_AP AP Example
  * @{
  */


/* Private types -------------------------------------------------------------------------------------------*/
typedef u32 (*pFunction)(u32, u32, u32);

/* Private constants ---------------------------------------------------------------------------------------*/
#define __DBG_APPrintf(...)
#define __DBG_AP_DumpData(...)

#if (AP_DEBUG_MODE == 1)
  #undef __DBG_APPrintf
  #undef __DBG_AP_DumpData
  #define __DBG_APPrintf printf
  static void __DBG_AP_DumpData(uc8 *memory, u32 len);
  #warning "================================= AP Debug Mode Warning ================================"
  #warning " 1. AP debug mode has been enable which degrade the performance.                        "
  #warning " 2. Note that print debug message too much may cause the AP command not synchronized.   "
  #warning " 3. After all debug operation is finished, please remember to turn off AP debug mode.   "
  #warning "========================================================================================"
#endif

#define MAX_CMD_LEN             (64)
#define MAX_TOKENS              (3)
#define CMD_COUNT               (6)

#define CMD_SUCCESS             ('O')
#define CMD_FAILED              ('F')

/* Private function prototypes -----------------------------------------------------------------------------*/
static u32 _AP_CMD0(u32 type, u32 saddr, u32 eaddr);

/* Private variables ---------------------------------------------------------------------------------------*/
#if 0
static u8 *gpCmdBuffer;
#endif
static u8 gResponseLength;

static const pFunction pFComHandlerTable[CMD_COUNT] =
{
  (pFunction)_AP_CMD0,
  (pFunction)_AP_CMD0,
  (pFunction)_AP_CMD0,
  (pFunction)_AP_CMD0,
  (pFunction)AP_Reset,
  (pFunction)_AP_CMD0
};

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  AP mode initialization.
  * @retval None
  ***********************************************************************************************************/
void AP_Init(void)
{
  #if (AP_DEBUG_MODE == 1)
  RETARGET_Configuration();
  #endif
}

/*********************************************************************************************************//**
  * @brief  IAP command handler.
  * @retval None
  ***********************************************************************************************************/
u32 IAP_CMDHandler(u8 *puCmdBuffer)
{
  u32 u32Parameter[MAX_TOKENS];
  u32 u32CommandExecuteResult;
  u16 crc;
  u16 crcValue;

  #if 0
  gpCmdBuffer = puCmdBuffer;
  #endif
  gResponseLength = 0;

  /*--------------------------------------------------------------------------------------------------------*/
  /* Check CRC value of command packet                                                                      */
  /*--------------------------------------------------------------------------------------------------------*/
  crc = puCmdBuffer[2] | ((u16)puCmdBuffer[3] << 8);
  puCmdBuffer[2] = puCmdBuffer[3] = 0;
  crcValue = CRC16(0, (u8 *)(&puCmdBuffer[0]), 64);

  /*--------------------------------------------------------------------------------------------------------*/
  /* Check command is valid and CRC is correct                                                              */
  /*--------------------------------------------------------------------------------------------------------*/
  if (puCmdBuffer[0] >= CMD_COUNT)
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* Command invalid. Return 'F' and clear command buffer                                                 */
    /*------------------------------------------------------------------------------------------------------*/
    u32CommandExecuteResult = CMD_FAILED;
  }
  else if (crc != crcValue)
  {
    u32CommandExecuteResult = CMD_FAILED;
  }
  else
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* Prepare parameter and execution command                                                              */
    /*------------------------------------------------------------------------------------------------------*/
    u32Parameter[0] = puCmdBuffer[1];
    u32Parameter[1] = *((u32 *)(&(puCmdBuffer[4])));
    u32Parameter[2] = *((u32 *)(&(puCmdBuffer[8])));

    u32CommandExecuteResult = (*pFComHandlerTable[puCmdBuffer[0]])(u32Parameter[0],
                                                                   u32Parameter[1],
                                                                   u32Parameter[2]);
  }

  puCmdBuffer[gResponseLength] = u32CommandExecuteResult;
  gResponseLength++;

  return gResponseLength;
}

/*********************************************************************************************************//**
  * @brief  Reset Command.
  * @param  uMode: Mode after reset
  * @retval CMD_SUCCESS or CMD_FAILED
  ***********************************************************************************************************/
u32 AP_Reset(u32 uMode)
{
  if (uMode == 0)
  {
    BOOT_MODE = BOOT_MODE_AP;
  }
  else
  {
    BOOT_MODE = BOOT_MODE_IAP;
  }

  IAPUser_Reset();

  return CMD_SUCCESS;
}

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  _AP_CMD0.
  * @param  type: TBD
  *         @arg TBD
  *         @arg TBD
  * @param  saddr: Start address
  * @param  eaddr: End address
  * @retval CMD_SUCCESS or CMD_FAILED
  ***********************************************************************************************************/
static u32 _AP_CMD0(u32 type, u32 saddr, u32 eaddr)
{
  return CMD_FAILED;
  //return CMD_SUCCESS;
}

#if (AP_DEBUG_MODE == 1)
/*********************************************************************************************************//**
  * @brief  Dump data for debug.
  * @param  memory
  * @param  Len
  * @retval None
  ***********************************************************************************************************/
static void __DBG_AP_DumpData(uc8 *memory, u32 len)
{
  u32 i;
  for (i = 0; i < len; i++)
  {
    if (i % 8 == 0)
    {
      if (i != 0)
      {
        __DBG_APPrintf("\r\n");
      }
      __DBG_APPrintf("\t\t");
    }
    __DBG_APPrintf("%02X ", *((u8 *)(memory + i)));
  }
  __DBG_APPrintf("\r\n");

  return;
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
