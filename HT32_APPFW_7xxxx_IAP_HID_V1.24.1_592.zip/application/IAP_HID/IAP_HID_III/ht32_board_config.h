/*********************************************************************************************************//**
 * @file    ht32_board_config.h
 * @version $Rev:: 578          $
 * @date    $Date:: 2026-11-02 #$
 * @brief   The header file of board configuration.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
#define IAP_CODE_SIZE                             (1024 * 10)        /* IAP code size in Bytes              */
#define IAP_VERSION_SIZE                          (16)

#define IAP_APFLASH_SIZE                          (LIBCFG_FLASH_SIZE)
#define IAP_APSRAM_SIZE                           (LIBCFG_RAM_SIZE)

#define IAP_APFLASH_START                         (IAP_CODE_SIZE)
#define IAP_APSRAM_START                          (HT_SRAM_BASE)

#define IAP_VER_ADDR                              (0x00000010)       /* AP Version address                  */
#define IAP_VERFLASH_START                        (IAP_APFLASH_START + IAP_VER_ADDR)

#define BOOT_MODE_AP                              (0x55AAFAF0)
#define BOOT_MODE_IAP                             (0x55AAFAF5)
#define BOOT_MODE_ID_ADDR                         (HT_SRAM_BASE)

#define BOOT_MODE                                 ((*((u32 volatile *) (BOOT_MODE_ID_ADDR))))

#define HARDWAVE_RESET_FIRST                      (0x55AAFBF0)
#define HARDWAVE_RESET                            ((*((u32 volatile *) (BOOT_MODE_ID_ADDR + 4))))

#define IAP_CMD_TIMEOUT_DISABLE                   (-1)
#define IAP_CMD_TIMEOUT_BUFFER_RELOAD             (300) /* Unit millisecond                                 */

#ifdef __cplusplus
}
#endif

#endif
