/*********************************************************************************************************//**
 * @file    IAP_HID/IAP_HID_III/Src_AP/ht32_usbd_class.c
 * @version $Rev:: 578          $
 * @date    $Date:: 2026-11-02 #$
 * @brief   The USB Device Class.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board_config.h"
#include "ht32_usbd_core.h"
#include "ht32_usbd_class.h"
#include "ap_handler.h"
#include "ap_config.h"
#include "common/ring_buffer.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_HID IAP HID
  * @{
  */

/** @addtogroup IAP_HID_III IAP HID III (with Encrypt and Command Key)
  * @{
  */

/** @addtogroup IAP_HID_III_AP AP Example
  * @{
  */


/* Private constants ---------------------------------------------------------------------------------------*/
#define CLASS_DESC_OFFSET                   (DESC_LEN_CONFN + DESC_LEN_INF)

#define CLASS_REQ_01_GET_RPOT               (u16)(0x1 << 8)
#define CLASS_REQ_02_GET_IDLE               (u16)(0x2 << 8)
#define CLASS_REQ_03_GET_PTCO               (u16)(0x3 << 8)
#define CLASS_REQ_09_SET_RPOT               (u16)(0x9 << 8)
#define CLASS_REQ_0A_SET_IDLE               (u16)(0xA << 8)
#define CLASS_REQ_0B_SET_PTCO               (u16)(0xB << 8)

#define HID_RPOT_TYPE_01_INPUT              (0x01)
#define HID_RPOT_TYPE_02_OUTPUT             (0x02)
#define HID_RPOT_TYPE_03_FEATURE            (0x03)

#define HID_IAP_CMDCH_INTOUT                (1)
#define HID_IAP_CMDCH_CTRLFEATURE           (2)

/* Private function prototypes -----------------------------------------------------------------------------*/
static void USBDClass_MainRoutine(u32 uPara);

static void USBDClass_Standard_GetDescriptor(USBDCore_Device_TypeDef *pDev);
static void USBDClass_Request(USBDCore_Device_TypeDef *pDev);
static void USBDClass_GetReport(USBDCore_Device_TypeDef *pDev);
static void USBDClass_SetReport(USBDCore_Device_TypeDef *pDev);

static void USBDClass_GetReportIAP(USBDCore_Device_TypeDef *pDev);
static void USBDClass_SetReportIAP(USBDCore_Device_TypeDef *pDev);
static void USBDClass_SetReportCallBackIAP(u32 uPara);
#if 0
static void USBDClass_EndpointIAPData(USBD_EPTn_Enum EPTn);
#endif
static void USBDClass_EndpointIAPCmd(USBD_EPTn_Enum EPTn);

/* Global variables ----------------------------------------------------------------------------------------*/
u8 guIAPCmdChannel = HID_IAP_CMDCH_INTOUT;

u8 guIAPIsCmdReady = FALSE;
__ALIGN4 u8 guIAPCmdBuffer[64];

#if 0
__ALIGN4 u8 guIAPDataTemp[64];
__ALIGN4 u8 guIAPDataBuffer[IAP_DATA_BUFFER_SIZE];
Buffer_TypeDef gIAPData;
#endif

__ALIGN4 u8 guIAPResponseTemp[64];
__ALIGN4 u8 guIAPResponseBuffer[IAP_RESPONSE_BUFFER_SIZE];
Buffer_TypeDef gIAPResponse;

#if 0
vu32 gIsIAPDataINEmpty = TRUE;
#endif

extern vs32 gIAPCmdTimeout;

/* Private variables ---------------------------------------------------------------------------------------*/

/* USB HID Report Descriptor                                                                                */
__ALIGN4 static uc8 USB_IAP_HID_ReportDesc[] = {
  0x06, IAP_HID_USAGE_PAGE_L, 0xff,  // USAGE PAGE (Vendor Defined Page nn 0xffnn)
  0x09, 0x01,                        // USAGE (Vendor Usage 1)
  0xA1, 0x01,                        // COLLECTION (Application)

  0x09, 0x02,                        //   USAGE (Vendor Usage 2)
  0x15, 0x00,                        //   LOGICAL_MINIMUM (0)
  0x26, 0xFF, 0x00,                  //   LOGICAL_MAXIMUM (255)
  0x75, 0x08,                        //   REPORT_SIZE (8)
  0x95, 0x40,                        //   REPORT_COUNT(64)
  0x81, 0x02,                        //   INPUT (Data, Var, Abs)

  0x09, 0x03,                        //   USAGE (Vendor Usage 3)
  0x15, 0x00,                        //   LOGICAL_MINIMUM (0)
  0x26, 0xFF, 0x00,                  //   LOGICAL_MAXIMUM (255)
  0x75, 0x08,                        //   REPORT_SIZE (8)
  0x95, 0x40,                        //   REPORT_COUNT (64)
  0x91, 0x02,                        //   OUTPUT (Data, Var, Abs)

  0x09, 0x04,                        //   USAGE (Vendor Usage 4)
  0x15, 0x00,                        //   LOGICAL_MINIMUM (0)
  0x26, 0xff, 0x00,                  //   LOGICAL_MAXIMUM (255)
  0x75, 0x08,                        //   REPORT_SIZE (8)
  0x95, 0x40,                        //   REPORT_COUNT (64)
  0xb1, 0x02,                        //   FEATURE (Data, Var, Abs)

  0xC0,                              // END_COLLECTION
};

/* Global Function -----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  USB Class initialization.
  * @param  pClass: pointer of USBDCore_Class_TypeDef
  * @retval None
  ***********************************************************************************************************/
void USBDClass_Init(USBDCore_Class_TypeDef *pClass)
{
  pClass->CallBack_MainRoutine.func = USBDClass_MainRoutine;
  //pClass->CallBack_MainRoutine.uPara = (u32)NULL;

  //pClass->CallBack_Reset.func = USBDClass_Reset;
  //pClass->CallBack_Reset.uPara = (u32)NULL;

  //pClass->CallBack_StartOfFrame.func = USBDClass_StartOfFrame;
  //pClass->CallBack_StartOfFrame.uPara = (u32)NULL;

  pClass->CallBack_ClassGetDescriptor = USBDClass_Standard_GetDescriptor;
  //pClass->CallBack_ClassSetInterface = USBDClass_Standard_SetInterface;

  pClass->CallBack_ClassRequest = USBDClass_Request;

  #if 0
  pClass->CallBack_EPTn[IAP_DATA_EPT] = USBDClass_EndpointIAPData;
  #endif
  pClass->CallBack_EPTn[IAP_CMD_EPT] = USBDClass_EndpointIAPCmd;

  #ifdef RETARGET_IS_USB
  pClass->CallBack_EPTn[RETARGET_RX_EPT] = SERIAL_USBDClass_RXHandler;
  #endif

  #if 0
  Buffer_Init(&gIAPData, guIAPDataBuffer, sizeof(guIAPDataBuffer));
  #endif
  Buffer_Init(&gIAPResponse, guIAPResponseBuffer, sizeof(guIAPResponseBuffer));

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Class main routine.
  * @param  uPara: Parameter for Class main routine
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_MainRoutine(u32 uPara)
{
  IAPUser_CmdProcess();

  return;
}

/*********************************************************************************************************//**
  * @brief  USB User level command process.
  * @retval None
  ***********************************************************************************************************/
void IAPUser_CmdProcess(void)
{
  u32 uResponseLength;

  if (guIAPIsCmdReady == TRUE)
  {
    uResponseLength = IAP_CMDHandler(&guIAPCmdBuffer[0]);

    if (Buffer_Write(&gIAPResponse, &guIAPCmdBuffer[0], uResponseLength) != uResponseLength)
    {
      #if (AP_DEBUG_MODE == 1)
      // Buffer problem
      while(1);
      #endif
    }

    gIAPCmdTimeout = IAP_CMD_TIMEOUT_BUFFER_RELOAD;

    guIAPIsCmdReady = FALSE;
  }

  if (gIAPCmdTimeout == 0)
  {
    Buffer_Discard(&gIAPResponse);
    gIAPCmdTimeout = IAP_CMD_TIMEOUT_DISABLE;
    return;
  }
}

#if 0
/*********************************************************************************************************//**
  * @brief  IAP User level send data.
  * @param  puData: Pointer of dada buffer for write
  * @param  uLength: Write length
  * @retval Total length sent by this function
  ***********************************************************************************************************/
u32 IAPUser_SendData(u8 *puData, u32 uLength)
{
  u32 uLen;

  if (guIAPCmdChannel == HID_IAP_CMDCH_INTOUT)
  {
    while (gIsIAPDataINEmpty == FALSE){};

    gIsIAPDataINEmpty = FALSE;
    uLen = USBDCore_EPTWriteINData((USBD_EPTn_Enum)IAP_DATA_EPT, (u32 *)puData, uLength);
  }
  else
  {
    while ((IAP_DATA_BUFFER_SIZE - Buffer_GetLength(&gIAPData)) < uLength){};

    uLen = Buffer_Write(&gIAPData, puData, uLength);
    #if (IAP_DEBUG_MODE == 1)
    if (uLen != uLength)
    {
      // Buffer problem
      while(1);
    }
    #endif
  }

  #if 0
  if (uLen != uLength)
  {
    while (1) {}; // Data overflow
  }
  #endif

  return uLen;
}
#endif

/* Private functions ---------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  USB Device Class Standard Request - GET_DESCRIPTOR
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_Standard_GetDescriptor(USBDCore_Device_TypeDef *pDev)
{
  u32 type = pDev->Request.wValueH;
  u32 index = pDev->Request.wIndex;

  switch (type)
  {
    case DESC_TYPE_21_HID:
    {
      pDev->Transfer.pData = (uc8 *)((pDev->Desc.pConfnDesc) + CLASS_DESC_OFFSET);
      pDev->Transfer.sByteLength = DESC_LEN_HID;
      pDev->Transfer.Action = USB_ACTION_DATAIN;
      break;
    }
    case DESC_TYPE_22_RPOT:
    {
      if (index == IAP_HID_INF)
      {
        pDev->Transfer.pData = (uc8 *)(USB_IAP_HID_ReportDesc);
        pDev->Transfer.sByteLength = DESC_LEN_RPOT_IAP;
        pDev->Transfer.Action = USB_ACTION_DATAIN;
      }
      break;
    }
    case DESC_TYPE_23_PHY:
    {
      break;
    }
  }

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device Class Request
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_Request(USBDCore_Device_TypeDef *pDev)
{
  u16 uUSBCmd = *((u16 *)(&(pDev->Request)));

#ifdef RETARGET_IS_USB
  SERIAL_USBDClass_Request(pDev);
#endif

  switch (uUSBCmd)
  {
    /*------------------------------------------------------------------------------------------------------*/
    /* | bRequest             | Data transfer direction | Type                | Recipient   | Data          */
    /*------------------------------------------------------------------------------------------------------*/

    /*------------------------------------------------------------------------------------------------------*/
    /* | 01_Get Report        | 80_Device-to-Host       | 20_Class Request    | 1_Interface | 01A1h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_01_GET_RPOT | REQ_DIR_01_D2H | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      __DBG_USBPrintf("%06ld GET RPOT\t[%02d][%02d]\r\n", __DBG_USBCount, pDev->Request.wValueH, pDev->Request.wLength);
      USBDClass_GetReport(pDev);
      break;
    }
    /*------------------------------------------------------------------------------------------------------*/
    /* | 02_Get Idle          | 80_Device-to-Host       | 20_Class Request    | 1_Interface | 02A1h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_02_GET_IDLE | REQ_DIR_01_D2H | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      break;
    }
    /*------------------------------------------------------------------------------------------------------*/
    /* | 03_Get Protocol      | 80_Device-to-Host       | 20_Class Request    | 1_Interface | 03A1h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_03_GET_PTCO | REQ_DIR_01_D2H | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      break;
    }
    /*------------------------------------------------------------------------------------------------------*/
    /* | 09_Set Report        | 00_Host-to-Device       | 20_Class Request    | 1_Interface | 0921h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_09_SET_RPOT | REQ_DIR_00_H2D | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      __DBG_USBPrintf("%06ld SET RPOT\t[%02d][%02d]\r\n", __DBG_USBCount, pDev->Request.wValueH, pDev->Request.wLength);
      USBDClass_SetReport(pDev);
      break;
    }
    /*------------------------------------------------------------------------------------------------------*/
    /* | 0A_Set Idle          | 00_Host-to-Device       | 20_Class Request    | 1_Interface | 0A21h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_0A_SET_IDLE | REQ_DIR_00_H2D | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      break;
    }
    /*------------------------------------------------------------------------------------------------------*/
    /* | 0B_Set Protocol      | 00_Host-to-Device       | 20_Class Request    | 1_Interface | 0B21h         */
    /*------------------------------------------------------------------------------------------------------*/
    case (CLASS_REQ_0B_SET_PTCO | REQ_DIR_00_H2D | REQ_TYPE_01_CLS | REQ_REC_01_INF):
    {
      break;
    }
  }

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device Class Request - GET_REPORT
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_GetReport(USBDCore_Device_TypeDef *pDev)
{
  #if 0
  u32 value = pDev->Request.wValueH;
  u32 ID = pDev->Request.wValueL;
  u32 len = pDev->Request.wLength;
  u32 inf = pDev->Request.wIndex;
  #endif

  USBDClass_GetReportIAP(pDev);

  #if 0
  switch (value)
  {
    case HID_RPOT_TYPE_01_INPUT:
    {
      if (inf == 0)
      {

      }
      break;
    }
    case HID_RPOT_TYPE_03_FEATURE:
    {
      if (inf == 0)
      {

      }
      break;
    }
  }
  #endif

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device Class Request - SET_REPORT
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_SetReport(USBDCore_Device_TypeDef *pDev)
{
  #if 0
  u32 value = pDev->Request.wValueH;
  u32 ID = pDev->Request.wValueL;
  u32 len = pDev->Request.wLength;
  u32 inf = pDev->Request.wIndex;
  #endif

  USBDClass_SetReportIAP(pDev);

  #if 0
  switch (value)
  {
    case HID_RPOT_TYPE_02_OUTPUT:
    {
      if (inf == 0)
      {

      }
      break;
    }
    case HID_RPOT_TYPE_03_FEATURE:
    {
      if (inf == 0)
      {

      }
      break;
    }
  }
  #endif

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device Class Request - GET_REPORT for IAP
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_GetReportIAP(USBDCore_Device_TypeDef *pDev)
{
  u32 value = pDev->Request.wValueH;
  u32 len = pDev->Request.wLength;
  u32 inf = pDev->Request.wIndex;

  if (inf == IAP_HID_INF)
  {
    switch (value)
    {
      case HID_RPOT_TYPE_01_INPUT:
      {
        if (Buffer_isEmpty(&gIAPResponse) == FALSE)
        {
          u32 uResponseLen;
          u32 i;
          uResponseLen = Buffer_Read(&gIAPResponse, guIAPResponseTemp, 64);
          for (i = len - 1; i >= uResponseLen; i--)
          {
            guIAPResponseTemp[i] = 0;
          }
          pDev->Transfer.pData = (uc8 *)guIAPResponseTemp;
          pDev->Transfer.sByteLength = len;
          pDev->Transfer.Action= USB_ACTION_DATAIN;
        }
        break;
      }
      case HID_RPOT_TYPE_03_FEATURE:
      {
        #if 0
        if (Buffer_GetLength(&gIAPData) >= 64)
        {
          Buffer_Read(&gIAPData, guIAPDataTemp, 64);
          pDev->Transfer.pData = (uc8 *)guIAPDataTemp;
          pDev->Transfer.sByteLength = len;
          pDev->Transfer.Action= USB_ACTION_DATAIN;
        }
        #endif
        break;
      }
    }
  }

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device Class Request - SET_REPORT for IAP
  * @param  pDev: pointer of USB Device
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_SetReportIAP(USBDCore_Device_TypeDef *pDev)
{
  u32 value = pDev->Request.wValueH;
  u32 len = pDev->Request.wLength;
  u32 inf = pDev->Request.wIndex;

  if ((inf == IAP_HID_INF) && (value == HID_RPOT_TYPE_03_FEATURE))
  {
    pDev->Transfer.pData = (uc8 *)&(guIAPCmdBuffer);
    pDev->Transfer.sByteLength = len;
    pDev->Transfer.Action= USB_ACTION_DATAOUT;
    pDev->Transfer.CallBack_OUT.func = USBDClass_SetReportCallBackIAP;
    pDev->Transfer.CallBack_OUT.uPara = len;
  }

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Device SET_REPORT call Back function for IAP Command
  * @param  uPara: Parameter for SET_REPORT call back function (SET_REPORT wLength)
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_SetReportCallBackIAP(u32 uPara)
{
  guIAPCmdChannel = HID_IAP_CMDCH_CTRLFEATURE;
  guIAPIsCmdReady = TRUE;

  return;
}

/*********************************************************************************************************//**
  * @brief  USB Class Endpoint handler for IAP Command
  * @param  EPTn: USB Endpoint number
  *         @arg USBD_EPT0 ~ USBD_EPT7
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_EndpointIAPCmd(USBD_EPTn_Enum EPTn)
{
  USBDCore_EPTReadOUTData(EPTn, (u32 *)(&(guIAPCmdBuffer[0])), 64);

  guIAPCmdChannel = HID_IAP_CMDCH_INTOUT;
  guIAPIsCmdReady = TRUE;

  return;
}

#if 0
/*********************************************************************************************************//**
  * @brief  USB Class Endpoint handler for IAP Data
  * @param  EPTn: USB Endpoint number
  *         @arg USBD_EPT0 ~ USBD_EPT7
  * @retval None
  ***********************************************************************************************************/
static void USBDClass_EndpointIAPData(USBD_EPTn_Enum EPTn)
{
  gIsIAPDataINEmpty = TRUE;
  return;
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
