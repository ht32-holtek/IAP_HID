/*********************************************************************************************************//**
 * @file    IAP_HID/IAP_HID_III/Src_AP/ht32_usbd_class.h
 * @version $Rev:: 731          $
 * @date    $Date:: 2025-06-25 #$
 * @brief   The header file of USB Device Class.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_USBD_CLASS_H
#define __HT32_USBD_CLASS_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_HID IAP HID
  * @{
  */

/** @addtogroup IAP_HID_III IAP HID III (with Encrypt and Command Key)
  * @{
  */

/** @addtogroup IAP_HID_III_AP AP Example
  * @{
  */


/* Settings ------------------------------------------------------------------------------------------------*/
/*  Buffer                                                                                                  */
#define IAP_DATA_BUFFER_SIZE                      (68) // Must >= required size + 1
#define IAP_RESPONSE_BUFFER_SIZE                  (68) // Must >= required size + 1

/* USB HID Setting                                                                                          */
#define IAP_HID_INF                               (0)

/* Exported constants --------------------------------------------------------------------------------------*/
#define USBD_HIDIAP_IN_EPT                        0x83
#define USBD_HIDIAP_OUT_EPT                       0x04

#define USBD_HIDIAP_IN_MAXPACKET_SIZE             0x40
#define USBD_HIDIAP_OUT_MAXPACKET_SIZE            0x40

typedef struct
{
  uint8_t g_rxhid_buff[USBD_HIDIAP_OUT_MAXPACKET_SIZE];
  uint32_t hid_protocol;
  uint32_t hid_set_idle;
  uint32_t alt_setting;
  uint32_t hid_state;
  uint32_t hid_value;
  uint32_t hid_id;
  uint32_t hid_len;
  uint32_t hid_inf;
  uint8_t hid_set_report[64];
  #if 0
  __IO uint8_t hid_reset_flag;
  #endif
  __IO uint8_t hid_suspend_flag;
} hid_info_type;

/* Exported functions --------------------------------------------------------------------------------------*/
extern usbd_class_handler hid_iap_class_handler;
extern hid_info_type hid_info;
usb_sts_type usb_iap_class_send_report(void *udev, uint8_t *report, uint16_t len);

void USBDClass_MainRoutine(void);

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif
