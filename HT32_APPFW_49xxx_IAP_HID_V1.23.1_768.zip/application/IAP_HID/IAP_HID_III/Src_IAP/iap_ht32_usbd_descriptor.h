/*********************************************************************************************************//**
 * @file    IAP_HID/IAP_HID_III/Src_IAP/iap_ht32_usbd_descriptor.h
 * @version $Rev:: 362          $
 * @date    $Date:: 2025-03-31 #$
 * @brief   The USB descriptor.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_USBD_DESCRIPTOR_H
#define __HT32_USBD_DESCRIPTOR_H

/* Includes ------------------------------------------------------------------------------------------------*/

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup IAP_HID IAP HID
  * @{
  */

/** @addtogroup IAP_HID_III IAP HID III (with Encrypt and Command Key)
  * @{
  */

/** @addtogroup IAP_HID_III_IAP IAP Example
  * @{
  */


/* Exported constants --------------------------------------------------------------------------------------*/
#define HIDIAP_BCD_NUM                          0x0110

#define USBD_HIDIAP_VENDOR_ID                   0x1234
#define USBD_HIDIAP_PRODUCT_ID                  0x0001

#define USBD_HIDIAP_CONFIG_DESC_SIZE            41
#define USBD_HIDIAP_SIZ_REPORT_DESC             47
#define USBD_HIDIAP_SIZ_STRING_LANGID           4
#define USBD_HIDIAP_SIZ_STRING_SERIAL           0x1A

#define USBD_HIDIAP_DESC_MANUFACTURER_STRING    "HOLTEK"
#define USBD_HIDIAP_DESC_PRODUCT_STRING         "USB-HID IAP"
#define USBD_HIDIAP_DESC_CONFIGURATION_STRING   "USB-HID IAP Config"
#define USBD_HIDIAP_DESC_INTERFACE_STRING       "USB-HID IAP Interface"

#define HIDIAP_BINTERVAL_TIME                   0x01

#define MCU_ID1                                 (0x1FFFF7E8)
#define MCU_ID2                                 (0x1FFFF7EC)
#define MCU_ID3                                 (0x1FFFF7F0)

extern uint8_t g_usbd_hidiap_report[USBD_HIDIAP_SIZ_REPORT_DESC];
extern uint8_t g_hidiap_usb_desc[9];

extern usbd_desc_handler hid_iap_desc_handler;

/* Exported functions --------------------------------------------------------------------------------------*/


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif
